import 'package:flutter/material.dart';

class MicIcon extends StatefulWidget {
  const MicIcon({super.key});

  @override
  State<MicIcon> createState() => _MicIconState();
}

class _MicIconState extends State<MicIcon> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}